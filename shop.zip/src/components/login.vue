<template>
    <div class="login">
        <input type="passworld">
        <input type="text">
        <button>点击</button>
    </div>
</template>
<script>
export default {

}
</script>
<style lang="sass" scoped>

</style>


